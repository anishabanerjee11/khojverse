import { GoogleGenerativeAI } from "@google/generative-ai";

const apiKey = (import.meta as any).env.VITE_GEMINI_API_KEY || "dummy-key";

export const genAI = new GoogleGenerativeAI(apiKey);

export const model = genAI.getGenerativeModel({ model: "gemini-pro" });

export const visionModel = genAI.getGenerativeModel({ model: "gemini-pro-vision" });

// Placeholder functions for different AI capabilities
export const generateText = async (prompt: string) => {
    if (!apiKey) return "API Key not configured. Please add VITE_GEMINI_API_KEY to .env";
    try {
        const result = await model.generateContent(prompt);
        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error("Error generating text:", error);
        return "Error generating response.";
    }
};

export const generateImageDescription = async (prompt: string, imagePart: any) => {
    if (!apiKey) return "API Key not configured.";
    try {
        const result = await visionModel.generateContent([prompt, imagePart]);
        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error("Error generating image description:", error);
        return "Error analyzing image.";
    }
};
