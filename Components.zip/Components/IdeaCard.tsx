import React from 'react';
import { IdeaItem, Popularity } from '../types';
import { motion } from 'framer-motion';
import { Eye, Clock, User, ArrowRight, Star } from 'lucide-react';

interface IdeaCardProps {
    idea: IdeaItem;
}

const IdeaCard: React.FC<IdeaCardProps> = ({ idea }) => {
    const getPopularityColor = (pop: Popularity) => {
        switch (pop) {
            case Popularity.High: return 'text-orange-500 bg-orange-50 dark:bg-orange-900/20 border-orange-100 dark:border-orange-900/30';
            case Popularity.Medium: return 'text-blue-500 bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-900/30';
            case Popularity.Low: return 'text-gray-500 bg-gray-50 dark:bg-gray-800 border-gray-100 dark:border-gray-700';
        }
    };

    return (
        <div className="glass rounded-[32px] p-6 h-full flex flex-col border border-white/60 dark:border-white/5 transition-all duration-300 group relative overflow-hidden hover:-translate-y-2 hover:shadow-2xl hover:shadow-teal-500/20 hover:border-teal-200 dark:hover:border-teal-800">


            <div className="flex justify-between items-start mb-4 relative z-10">
                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getPopularityColor(idea.popularity)}`}>
                    {idea.popularity} Interest
                </span>
                <span className="text-xs font-semibold text-gray-400 bg-white/50 dark:bg-white/5 px-2 py-1 rounded-lg border border-white/20">
                    {idea.category}
                </span>
            </div>

            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 leading-tight group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                {idea.title}
            </h3>

            <p className="text-gray-500 dark:text-gray-400 text-sm mb-6 line-clamp-3 flex-grow">
                {idea.description}
            </p>

            <div className="mt-auto space-y-4 relative z-10">
                <div className="flex flex-wrap gap-2">
                    {idea.tags.map(tag => (
                        <span key={tag} className="text-xs px-2.5 py-1 bg-gray-100 dark:bg-white/5 text-gray-600 dark:text-gray-300 rounded-lg font-medium group-hover:bg-teal-50 dark:group-hover:bg-teal-900/20 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                            #{tag}
                        </span>
                    ))}
                </div>

                <div className="pt-4 border-t border-gray-100 dark:border-white/5 flex items-center justify-between text-xs text-gray-400 dark:text-gray-500 font-medium">
                    <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1.5">
                            <Eye size={14} /> {idea.views.toLocaleString()}
                        </span>
                        {idea.date && (
                            <span className="flex items-center gap-1.5">
                                <Clock size={14} /> {idea.date}
                            </span>
                        )}
                    </div>

                    <button className="p-2 rounded-full bg-gray-50 dark:bg-white/5 hover:bg-teal-500 hover:text-white transition-all group/btn">
                        <ArrowRight size={16} className="group-hover/btn:-rotate-45 transition-transform duration-300" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default IdeaCard;
