import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
    MapPin, Link as LinkIcon, Calendar, Award, BookOpen, Users, Edit, Share2,
    Github, Linkedin, Mail, MessageCircle, MoreHorizontal, CheckCircle, Zap,
    TrendingUp, Code, GraduationCap, Building2, Globe
} from 'lucide-react';
import { User, Project, Activity, Achievement } from '../types';

interface ProfileProps {
    user: User;
    isOwnProfile?: boolean;
    onEditProfile?: () => void;
}

const Profile: React.FC<ProfileProps> = ({ user, isOwnProfile = true, onEditProfile }) => {
    const [activeTab, setActiveTab] = useState<'overview' | 'projects' | 'activity' | 'about'>('overview');

    return (
        <div className="w-full max-w-7xl mx-auto space-y-6 pb-20">
            {/* Header Section */}
            <div className="relative rounded-[40px] overflow-hidden glass border border-white/60 dark:border-white/5">
                {/* Cover Image */}
                <div className="h-60 w-full relative">
                    <img
                        src={user.coverImage || 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80'}
                        alt="Cover"
                        className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    {isOwnProfile && (
                        <button className="absolute top-6 right-6 p-2 glass rounded-full hover:bg-white/20 text-white transition-all">
                            <Edit size={20} />
                        </button>
                    )}
                </div>

                {/* Profile Info */}
                <div className="px-8 pb-8 relative">
                    <div className="flex flex-col md:flex-row gap-6 items-start md:items-end -mt-16 mb-6">
                        <div className="relative">
                            <div className="w-32 h-32 rounded-full border-4 border-white dark:border-slate-900 p-1 bg-white dark:bg-slate-900 overflow-hidden">
                                <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
                            </div>
                            {user.subscriptionStatus === 'Pro' && (
                                <div className="absolute bottom-1 right-1 bg-yellow-400 text-white p-1.5 rounded-full border-2 border-white dark:border-slate-900 shadow-lg" title="Pro Member">
                                    <Award size={16} fill="currentColor" />
                                </div>
                            )}
                        </div>

                        <div className="flex-grow space-y-1">
                            <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                                {user.name}
                                {user.username && <span className="text-lg text-gray-400 font-normal">@{user.username}</span>}
                            </h1>
                            <p className="text-gray-600 dark:text-gray-300 max-w-2xl">{user.bio || 'Life-long learner & innovator.'}</p>

                            <div className="flex flex-wrap gap-4 text-sm text-gray-500 dark:text-gray-400 mt-2">
                                {user.institution && (
                                    <div className="flex items-center gap-1.5">
                                        <Building2 size={16} />
                                        <span>{user.institution}</span>
                                    </div>
                                )}
                                {user.course && (
                                    <div className="flex items-center gap-1.5">
                                        <GraduationCap size={16} />
                                        <span>{user.course} • {user.semester}</span>
                                    </div>
                                )}
                                {user.socialLinks?.website && (
                                    <div className="flex items-center gap-1.5 text-teal-600 dark:text-teal-400 hover:underline cursor-pointer">
                                        <LinkIcon size={16} />
                                        <a href={user.socialLinks.website} target="_blank" rel="noreferrer">Website</a>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="flex gap-3 mt-4 md:mt-0">
                            {isOwnProfile ? (
                                <>
                                    <button className="px-6 py-2.5 bg-gray-100 dark:bg-white/10 text-gray-700 dark:text-white rounded-xl font-semibold hover:bg-gray-200 dark:hover:bg-white/20 transition-all flex items-center gap-2">
                                        <Share2 size={18} /> Share
                                    </button>
                                    <button
                                        onClick={onEditProfile}
                                        className="px-6 py-2.5 bg-teal-500 text-white rounded-xl font-bold shadow-lg shadow-teal-500/20 hover:bg-teal-600 transition-all flex items-center gap-2"
                                    >
                                        <Edit size={18} /> Edit Profile
                                    </button>
                                </>
                            ) : (
                                <button className="px-6 py-2.5 bg-teal-500 text-white rounded-xl font-bold shadow-lg shadow-teal-500/20 hover:bg-teal-600 transition-all flex items-center gap-2">
                                    <Users size={18} /> Follow
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Social Stats & Tabs */}
                    <div className="flex flex-col md:flex-row justify-between items-center border-t border-gray-200 dark:border-white/10 pt-6 gap-6">
                        <div className="flex gap-8">
                            <div className="text-center">
                                <div className="text-xl font-bold text-gray-900 dark:text-white">{user.followers || 0}</div>
                                <div className="text-xs text-gray-500 uppercase tracking-wide">Followers</div>
                            </div>
                            <div className="text-center">
                                <div className="text-xl font-bold text-gray-900 dark:text-white">{user.following || 0}</div>
                                <div className="text-xs text-gray-500 uppercase tracking-wide">Following</div>
                            </div>
                            <div className="text-center">
                                <div className="text-xl font-bold text-gray-900 dark:text-white">{user.streak || 0} 🔥</div>
                                <div className="text-xs text-gray-500 uppercase tracking-wide">Day Streak</div>
                            </div>
                        </div>

                        <div className="flex bg-gray-100 dark:bg-black/20 p-1 rounded-xl">
                            {(['overview', 'projects', 'activity', 'about'] as const).map(tab => (
                                <button
                                    key={tab}
                                    onClick={() => setActiveTab(tab)}
                                    className={`px-6 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${activeTab === tab
                                        ? 'bg-white dark:bg-slate-800 text-teal-600 shadow-sm'
                                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
                                        }`}
                                >
                                    {tab}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left Column - Stats & Skills */}
                <div className="space-y-6">
                    {/* Gamification Card */}
                    <div className="glass rounded-[32px] p-6 border border-white/60 dark:border-white/5">
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                            <Zap className="text-yellow-500" size={20} /> Level Progress
                        </h3>
                        <div className="mb-2 flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-300 font-medium">Level {user.level || 1}</span>
                            <span className="text-teal-500 font-bold">{user.rank || 'Novice'}</span>
                        </div>
                        <div className="h-3 w-full bg-gray-100 dark:bg-white/10 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-teal-400 to-emerald-500 w-[70%] rounded-full"></div>
                        </div>
                        <p className="text-xs text-gray-400 mt-2 text-center">350 XP to next level</p>
                    </div>

                    {/* Skills */}
                    <div className="glass rounded-[32px] p-6 border border-white/60 dark:border-white/5">
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                            <Code className="text-purple-500" size={20} /> Skills
                        </h3>
                        <div className="flex flex-wrap gap-2">
                            {user.skills?.map(skill => (
                                <span key={skill} className="px-3 py-1 bg-white dark:bg-white/5 border border-gray-100 dark:border-white/10 rounded-full text-sm text-gray-700 dark:text-gray-300">
                                    {skill}
                                </span>
                            )) || <p className="text-sm text-gray-400">No skills added yet.</p>}
                        </div>
                    </div>

                    {/* Achievements */}
                    <div className="glass rounded-[32px] p-6 border border-white/60 dark:border-white/5">
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                            <Award className="text-orange-500" size={20} /> Badges
                        </h3>
                        <div className="grid grid-cols-4 gap-4">
                            {user.badges?.map(badge => (
                                <div key={badge.id} className="flex flex-col items-center gap-1 group">
                                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center text-white shadow-lg transform group-hover:scale-110 transition-transform cursor-help" title={badge.title}>
                                        <span className="text-xl">{badge.icon}</span>
                                    </div>
                                </div>
                            )) || <p className="col-span-4 text-center text-sm text-gray-400 py-4">No badges yet</p>}
                        </div>
                    </div>
                </div>

                {/* Right Column - Content */}
                <div className="lg:col-span-2 space-y-6">
                    {activeTab === 'overview' && (
                        <>
                            {/* Recent Projects */}
                            <div className="glass rounded-[32px] p-8 border border-white/60 dark:border-white/5">
                                <div className="flex justify-between items-center mb-6">
                                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">Featured Projects</h3>
                                    <button className="text-teal-500 text-sm font-semibold hover:underline">View All</button>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {user.projects?.slice(0, 2).map(project => (
                                        <div key={project.id} className="group relative rounded-2xl overflow-hidden bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 hover:border-teal-500/50 transition-all">
                                            <div className="h-32 w-full overflow-hidden">
                                                <img src={project.image || `https://picsum.photos/seed/${project.id}/400/200`} alt={project.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                            </div>
                                            <div className="p-4">
                                                <h4 className="font-bold text-gray-900 dark:text-white mb-1 group-hover:text-teal-500 transition-colors">{project.title}</h4>
                                                <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 mb-3">{project.description}</p>
                                                <div className="flex flex-wrap gap-1">
                                                    {project.tags.slice(0, 3).map(tag => (
                                                        <span key={tag} className="text-[10px] px-2 py-0.5 bg-gray-200 dark:bg-white/10 rounded-full text-gray-600 dark:text-gray-300">#{tag}</span>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Activity Feed */}
                            <div className="glass rounded-[32px] p-8 border border-white/60 dark:border-white/5">
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Recent Activity</h3>
                                <div className="space-y-6">
                                    {user.recentActivity?.map((activity, idx) => (
                                        <div key={activity.id} className="flex gap-4 relative">
                                            {idx !== (user.recentActivity?.length || 0) - 1 && (
                                                <div className="absolute top-10 left-[19px] bottom-[-24px] w-0.5 bg-gray-200 dark:bg-white/10"></div>
                                            )}
                                            <div className="w-10 h-10 rounded-full bg-teal-50 dark:bg-teal-900/30 flex items-center justify-center shrink-0 border border-teal-100 dark:border-teal-800 text-teal-600 dark:text-teal-400">
                                                {activity.type === 'post' && <MessageCircle size={18} />}
                                                {activity.type === 'project' && <Code size={18} />}
                                                {activity.type === 'achievement' && <Award size={18} />}
                                                {activity.type === 'comment' && <MessageCircle size={18} />}
                                            </div>
                                            <div>
                                                <div className="text-sm text-gray-900 dark:text-white font-medium">
                                                    <span className="font-bold">{user.name}</span> {activity.content}
                                                </div>
                                                <div className="text-xs text-gray-400 mt-1">{activity.time}</div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </>
                    )}

                    {activeTab === 'projects' && (
                        <div className="glass rounded-[32px] p-8 border border-white/60 dark:border-white/5">
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">All Projects</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {user.projects?.map(project => (
                                    <div key={project.id} className="group relative rounded-2xl overflow-hidden bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 hover:border-teal-500/50 transition-all">
                                        <div className="h-40 w-full overflow-hidden">
                                            <img src={project.image || `https://picsum.photos/seed/${project.id}/400/200`} alt={project.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                        </div>
                                        <div className="p-5">
                                            <h4 className="font-bold text-gray-900 dark:text-white mb-2 group-hover:text-teal-500 transition-colors text-lg">{project.title}</h4>
                                            <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 mb-4">{project.description}</p>
                                            <div className="flex flex-wrap gap-2">
                                                {project.tags.map(tag => (
                                                    <span key={tag} className="text-xs px-2.5 py-1 bg-gray-200 dark:bg-white/10 rounded-full text-gray-600 dark:text-gray-300">#{tag}</span>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Profile;
