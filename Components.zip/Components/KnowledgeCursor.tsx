import React, { useEffect, useRef } from 'react';

interface Particle {
    x: number;
    y: number;
    vy: number;
    size: number;
    color: string;
    phase: number;
    type: 'bubble' | 'star';
    opacity: number;
}

const KnowledgeCursor: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const cursorRef = useRef({ x: -1000, y: -1000 });
    const particlesRef = useRef<Particle[]>([]);
    const lastTimeRef = useRef(0);
    const animationFrameRef = useRef<number>(0);
    const initialized = useRef(false);

    const colors = {
        teal: 'rgba(20, 184, 166,',
        cyan: 'rgba(34, 211, 238,',
        star: 'rgba(255, 255, 255,',
    };

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const handleResize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        window.addEventListener('resize', handleResize);
        handleResize();

        // Init bubbles and stars spread across entire screen
        if (!initialized.current) {
            // Stars (Static-ish background)
            for (let i = 0; i < 100; i++) {
                particlesRef.current.push({
                    x: Math.random() * window.innerWidth,
                    y: Math.random() * window.innerHeight, // Pre-distributed
                    vy: Math.random() * 0.05 + 0.02,
                    size: Math.random() * 1.5,
                    color: colors.star,
                    phase: Math.random() * Math.PI * 2,
                    type: 'star',
                    opacity: Math.random() * 0.5 + 0.2
                });
            }
            // Bubbles (Moving upward)
            for (let i = 0; i < 180; i++) {
                particlesRef.current.push({
                    x: Math.random() * window.innerWidth,
                    y: Math.random() * window.innerHeight, // Pre-distributed
                    vy: Math.random() * 0.3 + 0.1,
                    size: Math.random() * 3 + 1,
                    color: Math.random() > 0.5 ? colors.teal : colors.cyan,
                    phase: Math.random() * Math.PI * 2,
                    type: 'bubble',
                    opacity: Math.random() * 0.25 + 0.1
                });
            }
            initialized.current = true;
        }

        const handleMouseMove = (e: MouseEvent) => {
            cursorRef.current.x = e.clientX;
            cursorRef.current.y = e.clientY;
        };
        window.addEventListener('mousemove', handleMouseMove);

        const animate = (time: number) => {
            const deltaTime = time - lastTimeRef.current;
            lastTimeRef.current = time;

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.globalCompositeOperation = 'lighter';

            particlesRef.current.forEach(p => {
                // Movement
                p.y -= p.vy * (deltaTime * 0.05);
                p.x += Math.sin(time * 0.0008 + p.phase) * (p.type === 'star' ? 0.05 : 0.15);

                // Seamless wrap around
                if (p.y < -10) {
                    p.y = canvas.height + 10;
                    p.x = Math.random() * canvas.width;
                }

                // Interaction for bubbles only
                if (p.type === 'bubble') {
                    const dx = p.x - cursorRef.current.x;
                    const dy = p.y - cursorRef.current.y;
                    const dist = Math.hypot(dx, dy);

                    if (dist < 100 && dist > 0) {
                        const force = (100 - dist) / 100;
                        p.x += (dx / dist) * force * 3;
                        p.y += (dy / dist) * force * 3;
                    }
                }

                // Draw
                const flicker = p.type === 'star' ? Math.sin(time * 0.002 + p.phase) * 0.2 : 0;
                ctx.fillStyle = `${p.color}${Math.max(0, p.opacity + flicker)})`;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });

            ctx.globalCompositeOperation = 'source-over';
            animationFrameRef.current = requestAnimationFrame(animate);
        };
        animationFrameRef.current = requestAnimationFrame(animate);

        return () => {
            window.removeEventListener('resize', handleResize);
            window.removeEventListener('mousemove', handleMouseMove);
            cancelAnimationFrame(animationFrameRef.current);
        };
    }, []);

    // z-index: 0 puts particles BEHIND everything
    return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />;
};

export default KnowledgeCursor;
