import React from 'react';
import { motion } from 'framer-motion';

interface LoginProps {
    onLogin: (e: React.FormEvent) => void;
    onSignupClick: () => void;
    onBackClick: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, onSignupClick, onBackClick }) => {
    return (
        <div className="flex items-center justify-center min-h-screen p-4 relative z-[100]">
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white dark:bg-gray-900 w-full max-w-4xl p-10 rounded-[40px] shadow-2xl border border-gray-100 dark:border-gray-800"
            >
                <div className="text-center mb-10">
                    <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">Welcome Back</h2>
                    <p className="text-gray-500 dark:text-gray-400">Sign in to the Universe of Ideas</p>
                </div>

                <form onSubmit={onLogin} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 ml-1">Email Address</label>
                        <input
                            type="email"
                            required
                            placeholder="explorer@khojverse.io"
                            className="w-full px-6 py-4 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-800 focus:ring-2 focus:ring-teal-400 outline-none glass text-gray-900 dark:text-white transition-all"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 ml-1">Password</label>
                        <input
                            type="password"
                            required
                            placeholder="••••••••"
                            className="w-full px-6 py-4 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-800 focus:ring-2 focus:ring-teal-400 outline-none glass text-gray-900 dark:text-white transition-all"
                        />
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-teal-500 text-white py-4 rounded-2xl font-bold hover:bg-teal-600 transition-all shadow-xl shadow-teal-100 dark:shadow-teal-900/40 active:scale-[0.98]"
                    >
                        Log In
                    </button>
                </form>

                <div className="mt-8 pt-8 border-t border-gray-100 dark:border-gray-800">
                    <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                        Don't have an account?{' '}
                        <button
                            onClick={onSignupClick}
                            className="text-teal-600 dark:text-teal-400 font-medium hover:underline"
                        >
                            Sign Up
                        </button>
                    </p>
                </div>

                <div className="mt-4 text-center">
                    <button
                        onClick={onBackClick}
                        className="text-gray-400 dark:text-gray-500 text-sm hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                    >
                        Go Back to Landing
                    </button>
                </div>
            </motion.div>
        </div>
    );
};

export default Login;
