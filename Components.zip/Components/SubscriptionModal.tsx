import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Crown, Check } from 'lucide-react';

interface SubscriptionModalProps {
    isOpen: boolean;
    onClose: () => void;
    onUpgrade: () => void;
}

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, onUpgrade }) => {
    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                        onClick={onClose}
                    />
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 20 }}
                        className="relative bg-white dark:bg-gray-900 w-full max-w-md rounded-[32px] p-8 shadow-2xl overflow-hidden border border-teal-200 dark:border-teal-800"
                    >
                        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-teal-400 to-purple-500" />

                        <div className="w-16 h-16 bg-gradient-to-br from-teal-400 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/30">
                            <Crown className="text-white" size={32} />
                        </div>

                        <h2 className="text-2xl font-bold text-center text-gray-900 dark:text-white mb-2">
                            Upgrade to Pro
                        </h2>
                        <p className="text-center text-gray-500 dark:text-gray-400 mb-8">
                            Your free session for this premium feature has ended. Unlock limitless potential with KhojVerse Pro.
                        </p>

                        <div className="space-y-4 mb-8">
                            <div className="flex items-center gap-3">
                                <div className="w-6 h-6 rounded-full bg-teal-100 dark:bg-teal-900/50 flex items-center justify-center text-teal-600 dark:text-teal-400">
                                    <Check size={14} strokeWidth={3} />
                                </div>
                                <span className="text-gray-700 dark:text-gray-300 font-medium">Unlimited AI Lab Access</span>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="w-6 h-6 rounded-full bg-teal-100 dark:bg-teal-900/50 flex items-center justify-center text-teal-600 dark:text-teal-400">
                                    <Check size={14} strokeWidth={3} />
                                </div>
                                <span className="text-gray-700 dark:text-gray-300 font-medium">Uninterrupted Live Sync</span>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="w-6 h-6 rounded-full bg-teal-100 dark:bg-teal-900/50 flex items-center justify-center text-teal-600 dark:text-teal-400">
                                    <Check size={14} strokeWidth={3} />
                                </div>
                                <span className="text-gray-700 dark:text-gray-300 font-medium">Priority Support</span>
                            </div>
                        </div>

                        <button
                            onClick={onUpgrade}
                            className="w-full py-4 bg-gradient-to-r from-teal-500 to-purple-600 text-white rounded-2xl font-bold text-lg shadow-xl shadow-purple-500/20 hover:shadow-purple-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all"
                        >
                            Get Pro - $9.99/mo
                        </button>
                        <button
                            onClick={onClose}
                            className="w-full mt-4 py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 font-medium text-sm transition-colors"
                        >
                            Maybe Later
                        </button>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
};

export default SubscriptionModal;
