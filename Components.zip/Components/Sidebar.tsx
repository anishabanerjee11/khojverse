import React from 'react';
import { Category } from '../types';
import {
    TrendingUp,
    Award,
    Lightbulb,
    BookOpen,
    FileText,
    Bookmark,
    LogOut,
    Zap
} from 'lucide-react';

interface SidebarProps {
    activeCategory: Category;
    setActiveCategory: (category: Category) => void;
    onLogout: () => void;
    credits: number;
}

const Sidebar: React.FC<SidebarProps> = ({ activeCategory, setActiveCategory, onLogout, credits }) => {
    const categories: { name: Category; icon: React.ReactNode }[] = [
        { name: 'Trending', icon: <TrendingUp size={20} /> },
        { name: 'Hackathons', icon: <Award size={20} /> },
        { name: 'Projects', icon: <Lightbulb size={20} /> },
        { name: 'Research', icon: <BookOpen size={20} /> },
        { name: 'Articles', icon: <FileText size={20} /> },
        { name: 'Saved', icon: <Bookmark size={20} /> }
    ];

    return (
        <div className="flex flex-col h-full justify-between">
            <div>
                <div className="mb-6 px-2">
                    <p className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2">Discover</p>
                </div>
                <nav className="space-y-2">
                    {categories.map((cat) => (
                        <button
                            key={cat.name}
                            onClick={() => setActiveCategory(cat.name)}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-300 ${activeCategory === cat.name
                                ? 'bg-teal-500 text-white shadow-lg shadow-teal-200 dark:shadow-teal-900/50'
                                : 'text-gray-500 dark:text-gray-400 hover:bg-teal-50 dark:hover:bg-teal-900/20 hover:text-teal-600 dark:hover:text-teal-400'
                                }`}
                        >
                            <div className={`${activeCategory === cat.name ? 'text-white' : ''}`}>
                                {cat.icon}
                            </div>
                            <span className="font-medium">{cat.name}</span>
                        </button>
                    ))}
                </nav>
            </div>

            <div className="mt-auto">
                <button
                    onClick={onLogout}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-gray-500 dark:text-gray-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500 transition-all duration-300"
                >
                    <LogOut size={20} />
                    <span className="font-medium">Logout</span>
                </button>
            </div>
        </div>
    );
};

export default Sidebar;
