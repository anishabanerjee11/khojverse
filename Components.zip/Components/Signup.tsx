import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Check, X, ArrowRight, Github, Mail } from 'lucide-react';
import { User } from '../types';

interface SignupProps {
    onSignup: (user: User) => void;
    onLoginClick: () => void;
}

const INTERESTS_LIST = [
    'Artificial Intelligence', 'Space Exploration', 'Biotech', 'Quantum Computing',
    'Robotics', 'Virtual Reality', 'Sustainability', 'Blockchain', 'Neuroscience',
    'Cybersecurity', 'Game Dev', 'Internet of Things'
];

const Signup: React.FC<SignupProps> = ({ onSignup, onLoginClick }) => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: ''
    });
    const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
    const [showPassword, setShowPassword] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const validatePassword = (pass: string) => {
        const hasUpper = /[A-Z]/.test(pass);
        const hasLower = /[a-z]/.test(pass);
        const hasNumber = /[0-9]/.test(pass);
        const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass);
        const isValidLength = pass.length >= 8;
        return hasUpper && hasLower && hasNumber && hasSpecial && isValidLength;
    };

    const handleNext = (e: React.FormEvent) => {
        e.preventDefault();
        const newErrors: Record<string, string> = {};

        if (!formData.name) newErrors.name = 'Full Name is required';
        if (!formData.email) newErrors.email = 'Email is required';
        if (!formData.phone) newErrors.phone = 'Phone number is required';
        if (!validatePassword(formData.password)) {
            newErrors.password = 'Password must have 8+ chars, uppercase, lowercase, number, and special char.';
        }
        if (formData.password !== formData.confirmPassword) {
            newErrors.confirmPassword = 'Passwords do not match';
        }

        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
            return;
        }

        setStep(2);
    };

    const handleSignup = () => {
        if (selectedInterests.length === 0) {
            setErrors({ interests: 'Please select at least one topic.' });
            return;
        }

        const newUser: User = {
            name: formData.name,
            username: formData.email.split('@')[0], // Generate username from email
            email: formData.email,
            avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(formData.name)}&background=14b8a6&color=fff`,
            phoneNumber: formData.phone,
            interestedTopics: selectedInterests,
            subscriptionStatus: 'Free',
            credits: 500
        };

        onSignup(newUser);
    };

    const toggleInterest = (interest: string) => {
        if (selectedInterests.includes(interest)) {
            setSelectedInterests(selectedInterests.filter(i => i !== interest));
        } else {
            setSelectedInterests([...selectedInterests, interest]);
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen p-4">
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white dark:bg-gray-900 w-full max-w-4xl p-10 rounded-[40px] shadow-2xl border border-gray-100 dark:border-gray-800"
            >
                <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">
                        {step === 1 ? 'Create Account' : step === 2 ? 'Verify Email' : 'Choose Your Interests'}
                    </h2>
                    <p className="text-gray-500 dark:text-gray-400">
                        {step === 1 ? 'Join the multiverse of ideas' : step === 2 ? 'Enter the code sent to your email' : 'Personalize your feed'}
                    </p>
                </div>

                {step === 1 && (
                    <form onSubmit={handleNext} className="space-y-4">
                        <div>
                            <input
                                type="text"
                                placeholder="Full Name"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                className="w-full px-6 py-4 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-800 focus:ring-2 focus:ring-teal-400 outline-none glass text-gray-900 dark:text-white transition-all"
                            />
                            {errors.name && <p className="text-red-500 text-xs mt-1 ml-2">{errors.name}</p>}
                        </div>

                        <div>
                            <input
                                type="email"
                                placeholder="Email Address"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                className="w-full px-6 py-4 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-800 focus:ring-2 focus:ring-teal-400 outline-none glass text-gray-900 dark:text-white transition-all"
                            />
                            {errors.email && <p className="text-red-500 text-xs mt-1 ml-2">{errors.email}</p>}
                        </div>

                        <div>
                            <input
                                type="tel"
                                placeholder="Phone Number"
                                value={formData.phone}
                                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                className="w-full px-6 py-4 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-800 focus:ring-2 focus:ring-teal-400 outline-none glass text-gray-900 dark:text-white transition-all"
                            />
                            {errors.phone && <p className="text-red-500 text-xs mt-1 ml-2">{errors.phone}</p>}
                        </div>

                        <div className="relative">
                            <input
                                type={showPassword ? 'text' : 'password'}
                                placeholder="Password"
                                value={formData.password}
                                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                className="w-full px-6 py-4 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-800 focus:ring-2 focus:ring-teal-400 outline-none glass text-gray-900 dark:text-white transition-all"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-4 top-4 text-gray-400"
                            >
                                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                            </button>
                            {errors.password && <p className="text-red-500 text-xs mt-1 ml-2">{errors.password}</p>}
                        </div>

                        <div>
                            <input
                                type="password"
                                placeholder="Confirm Password"
                                value={formData.confirmPassword}
                                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                                className="w-full px-6 py-4 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-800 focus:ring-2 focus:ring-teal-400 outline-none glass text-gray-900 dark:text-white transition-all"
                            />
                            {errors.confirmPassword && <p className="text-red-500 text-xs mt-1 ml-2">{errors.confirmPassword}</p>}
                        </div>

                        <button
                            type="submit"
                            className="w-full bg-teal-500 text-white py-4 rounded-2xl font-bold hover:bg-teal-600 transition-all shadow-xl shadow-teal-100 dark:shadow-teal-900/40 active:scale-[0.98] flex justify-center items-center gap-2"
                        >
                            Send Verification Code <ArrowRight size={18} />
                        </button>

                        <div className="flex gap-4 mt-4">
                            <button type="button" className="flex-1 py-3 rounded-xl border border-gray-200 dark:border-white/10 flex justify-center items-center gap-2 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors text-gray-700 dark:text-gray-300">
                                <span className="font-bold">G</span> Google
                            </button>
                            <button type="button" className="flex-1 py-3 rounded-xl border border-gray-200 dark:border-white/10 flex justify-center items-center gap-2 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors text-gray-700 dark:text-gray-300">
                                <Github size={18} /> Github
                            </button>
                        </div>
                    </form>
                )}

                {step === 2 && (
                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="space-y-6"
                    >
                        <div className="bg-teal-50 dark:bg-teal-900/20 p-4 rounded-2xl flex items-center gap-3 border border-teal-100 dark:border-teal-900/50">
                            <Mail className="text-teal-500" />
                            <p className="text-sm text-gray-600 dark:text-gray-300">
                                We sent a 4-digit code to <span className="font-bold text-gray-800 dark:text-white">{formData.email}</span>
                            </p>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Enter Verification Code (Try 1234)</label>
                            <div className="flex gap-4 justify-between">
                                {[0, 1, 2, 3].map((i) => (
                                    <input
                                        key={i}
                                        type="text"
                                        maxLength={1}
                                        className="w-16 h-16 text-center text-2xl font-bold rounded-2xl border-none ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-2 focus:ring-teal-400 glass outline-none"
                                        onChange={(e) => {
                                            if (e.target.value.length === 1) {
                                                const nextSibling = document.getElementById(`otp-${i + 1}`);
                                                if (nextSibling) (nextSibling as HTMLInputElement).focus();
                                            }
                                        }}
                                        id={`otp-${i}`}
                                    />
                                ))}
                            </div>
                        </div>

                        <button
                            onClick={() => setStep(3)}
                            className="w-full bg-teal-500 text-white py-4 rounded-2xl font-bold hover:bg-teal-600 transition-all shadow-xl shadow-teal-100 dark:shadow-teal-900/40 active:scale-[0.98]"
                        >
                            Verify & Continue
                        </button>

                        <button
                            onClick={() => setStep(1)}
                            className="w-full text-gray-500 dark:text-gray-400 text-sm hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
                        >
                            Back to details
                        </button>
                    </motion.div>
                )}

                {step === 3 && (
                    <div className="space-y-6">
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                            {INTERESTS_LIST.map((interest) => (
                                <button
                                    key={interest}
                                    onClick={() => toggleInterest(interest)}
                                    className={`px-4 py-3 rounded-xl text-sm font-medium transition-all text-left flex justify-between items-center ${selectedInterests.includes(interest)
                                        ? 'bg-teal-500 text-white shadow-lg shadow-teal-200 dark:shadow-teal-900/50'
                                        : 'bg-white/50 dark:bg-white/5 text-gray-600 dark:text-gray-300 hover:bg-teal-50 dark:hover:bg-teal-900/20'
                                        }`}
                                >
                                    {interest}
                                    {selectedInterests.includes(interest) && <Check size={16} />}
                                </button>
                            ))}
                        </div>
                        {errors.interests && <p className="text-red-500 text-center">{errors.interests}</p>}

                        <button
                            onClick={handleSignup}
                            className="w-full bg-teal-500 text-white py-4 rounded-2xl font-bold hover:bg-teal-600 transition-all shadow-xl shadow-teal-100 dark:shadow-teal-900/40 active:scale-[0.98]"
                        >
                            Complete Signup
                        </button>

                        <button
                            onClick={() => setStep(3)}
                            className="w-full text-gray-500 dark:text-gray-400 text-sm hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
                        >
                            Back to details
                        </button>
                    </div>
                )}

                <div className="mt-8 pt-8 border-t border-gray-100 dark:border-gray-800 text-center">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                        Already have an account?{' '}
                        <button onClick={onLoginClick} className="text-teal-600 dark:text-teal-400 font-medium hover:underline">
                            Log In
                        </button>
                    </p>
                </div>
            </motion.div>
        </div>
    );
};

export default Signup;
