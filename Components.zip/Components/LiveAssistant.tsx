import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Mic, Radio, Users, Square, Play, BarChart2, MessageSquare,
    Share2, Settings, PenTool, Type, StickyNote, Image as ImageIcon,
    Eraser, Undo, Redo, MoreHorizontal, Send, Phone, Video,
    Lock, Unlock, Clock, CheckCircle, Plus, Smile, X, Download,
    MousePointer2, ChevronRight, ChevronLeft, Search, Trash2
} from 'lucide-react';

// Types
interface Participant {
    id: string;
    name: string;
    avatar: string;
    status: 'online' | 'idle' | 'typing';
    color: string;
}

interface ChatMessage {
    id: string;
    senderId: string;
    text: string;
    timestamp: string;
}

interface DrawingPath {
    id: string;
    points: { x: number; y: number }[];
    color: string;
    strokeWidth: number;
}

interface StickyNoteItem {
    id: string;
    x: number;
    y: number;
    text: string;
    color: string;
}

interface TextItem {
    id: string;
    x: number;
    y: number;
    text: string;
}

const STICKY_COLORS = ['#fef08a', '#bbf7d0', '#bfdbfe', '#fecaca', '#e9d5ff'];

const LiveAssistant: React.FC = () => {
    const [activeTool, setActiveTool] = useState('cursor');
    const [isChatOpen, setIsChatOpen] = useState(true);
    const [messageInput, setMessageInput] = useState('');
    const [isSessionLocked, setIsSessionLocked] = useState(false);

    // Canvas & Drawing State
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [paths, setPaths] = useState<DrawingPath[]>([]);
    const [currentPath, setCurrentPath] = useState<{ x: number; y: number }[]>([]);
    const [penColor, setPenColor] = useState('#14b8a6');
    const [penWidth, setPenWidth] = useState(3);

    // Sticky Notes & Text
    const [stickyNotes, setStickyNotes] = useState<StickyNoteItem[]>([
        { id: '1', x: 60, y: 80, text: 'Project Goals 🎯\n• Analyze user retention\n• Draft findings report\n• Sync with design team', color: '#fef08a' }
    ]);
    const [textItems, setTextItems] = useState<TextItem[]>([]);
    const [editingTextId, setEditingTextId] = useState<string | null>(null);
    const [editingStickyId, setEditingStickyId] = useState<string | null>(null);

    // History for Undo/Redo
    const [history, setHistory] = useState<{ paths: DrawingPath[]; stickyNotes: StickyNoteItem[]; textItems: TextItem[] }[]>([]);
    const [historyIndex, setHistoryIndex] = useState(-1);

    // Mock Participants
    const participants: Participant[] = [
        { id: '1', name: 'You', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80', status: 'online', color: '#14b8a6' },
        { id: '2', name: 'David', avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=100&q=80', status: 'typing', color: '#f59e0b' },
        { id: '3', name: 'Sarah', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=100&q=80', status: 'online', color: '#8b5cf6' },
    ];

    // Mock Chat
    const [messages, setMessages] = useState<ChatMessage[]>([
        { id: '1', senderId: '2', text: 'Hey team, I added the new research stats to the board.', timestamp: '10:02 AM' },
        { id: '2', senderId: '3', text: 'Looks great! I\'m verifying the citations now.', timestamp: '10:03 AM' },
    ]);

    // Simulated Cursors
    const [cursors, setCursors] = useState<{ id: string, x: number, y: number }[]>([
        { id: '2', x: 300, y: 200 },
        { id: '3', x: 500, y: 350 },
    ]);

    // Simulate remote user activity
    useEffect(() => {
        const interval = setInterval(() => {
            setCursors(prev => prev.map(c => ({
                ...c,
                x: Math.max(50, Math.min(800, c.x + (Math.random() - 0.5) * 40)),
                y: Math.max(50, Math.min(500, c.y + (Math.random() - 0.5) * 40))
            })));
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    // Redraw canvas when paths change
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Draw all saved paths
        paths.forEach(path => {
            if (path.points.length < 2) return;
            ctx.beginPath();
            ctx.strokeStyle = path.color;
            ctx.lineWidth = path.strokeWidth;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.moveTo(path.points[0].x, path.points[0].y);
            path.points.forEach(pt => ctx.lineTo(pt.x, pt.y));
            ctx.stroke();
        });

        // Draw current path being drawn
        if (currentPath.length > 1) {
            ctx.beginPath();
            ctx.strokeStyle = penColor;
            ctx.lineWidth = penWidth;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.moveTo(currentPath[0].x, currentPath[0].y);
            currentPath.forEach(pt => ctx.lineTo(pt.x, pt.y));
            ctx.stroke();
        }
    }, [paths, currentPath, penColor, penWidth]);

    // Drawing handlers
    const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
        if (activeTool !== 'pen' && activeTool !== 'eraser') return;
        const rect = canvasRef.current?.getBoundingClientRect();
        if (!rect) return;
        setIsDrawing(true);
        setCurrentPath([{ x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    };

    const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
        if (!isDrawing) return;
        const rect = canvasRef.current?.getBoundingClientRect();
        if (!rect) return;
        setCurrentPath(prev => [...prev, { x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    };

    const handleCanvasMouseUp = () => {
        if (!isDrawing) return;
        setIsDrawing(false);
        if (currentPath.length > 1) {
            const newPath: DrawingPath = {
                id: Date.now().toString(),
                points: currentPath,
                color: activeTool === 'eraser' ? '#ffffff' : penColor,
                strokeWidth: activeTool === 'eraser' ? 20 : penWidth,
            };
            setPaths(prev => [...prev, newPath]);
            saveHistory();
        }
        setCurrentPath([]);
    };

    // Add Sticky Note
    const handleAddStickyNote = (e: React.MouseEvent<HTMLDivElement>) => {
        if (activeTool !== 'sticky') return;
        const rect = e.currentTarget.getBoundingClientRect();
        const newNote: StickyNoteItem = {
            id: Date.now().toString(),
            x: e.clientX - rect.left - 75,
            y: e.clientY - rect.top - 50,
            text: 'New note...',
            color: STICKY_COLORS[Math.floor(Math.random() * STICKY_COLORS.length)],
        };
        setStickyNotes(prev => [...prev, newNote]);
        setEditingStickyId(newNote.id);
        saveHistory();
    };

    // Add Text
    const handleAddText = (e: React.MouseEvent<HTMLDivElement>) => {
        if (activeTool !== 'text') return;
        const rect = e.currentTarget.getBoundingClientRect();
        const newText: TextItem = {
            id: Date.now().toString(),
            x: e.clientX - rect.left,
            y: e.clientY - rect.top,
            text: 'Type here...',
        };
        setTextItems(prev => [...prev, newText]);
        setEditingTextId(newText.id);
        saveHistory();
    };

    // Save history for undo/redo
    const saveHistory = () => {
        const newState = { paths: [...paths], stickyNotes: [...stickyNotes], textItems: [...textItems] };
        setHistory(prev => [...prev.slice(0, historyIndex + 1), newState]);
        setHistoryIndex(prev => prev + 1);
    };

    const handleUndo = () => {
        if (historyIndex <= 0) return;
        const prevState = history[historyIndex - 1];
        setPaths(prevState.paths);
        setStickyNotes(prevState.stickyNotes);
        setTextItems(prevState.textItems);
        setHistoryIndex(prev => prev - 1);
    };

    const handleRedo = () => {
        if (historyIndex >= history.length - 1) return;
        const nextState = history[historyIndex + 1];
        setPaths(nextState.paths);
        setStickyNotes(nextState.stickyNotes);
        setTextItems(nextState.textItems);
        setHistoryIndex(prev => prev + 1);
    };

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (!messageInput.trim()) return;
        setMessages(prev => [
            ...prev,
            { id: Date.now().toString(), senderId: '1', text: messageInput, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
        ]);
        setMessageInput('');
    };

    const handleDeleteSticky = (id: string) => {
        setStickyNotes(prev => prev.filter(n => n.id !== id));
        saveHistory();
    };

    const handleDeleteText = (id: string) => {
        setTextItems(prev => prev.filter(t => t.id !== id));
        saveHistory();
    };

    return (
        <div className="h-[calc(100vh-140px)] flex flex-col glass rounded-[40px] overflow-hidden border border-white/60 dark:border-white/5 relative">

            {/* Top Bar */}
            <header className="h-16 border-b border-gray-200 dark:border-white/10 px-6 flex items-center justify-between bg-white/40 dark:bg-black/20 backdrop-blur-md z-20">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                        <span className="font-bold text-gray-800 dark:text-white">Live Sync</span>
                    </div>
                    <div className="h-6 w-px bg-gray-300 dark:bg-white/10"></div>
                    <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                        <Clock size={14} /> 00:42:15
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <div className="flex -space-x-2">
                        {participants.map(p => (
                            <div key={p.id} className="relative group cursor-pointer" title={p.name}>
                                <img src={p.avatar} alt={p.name} className={`w-8 h-8 rounded-full border-2 border-white dark:border-slate-800 object-cover ${p.status === 'idle' ? 'opacity-50' : ''}`} />
                                <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border border-white dark:border-slate-800 ${p.status === 'online' || p.status === 'typing' ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
                            </div>
                        ))}
                        <button className="w-8 h-8 rounded-full bg-gray-100 dark:bg-white/10 flex items-center justify-center text-gray-500 border-2 border-white dark:border-slate-800 hover:bg-teal-50 dark:hover:bg-teal-900/20 hover:text-teal-500 transition-colors">
                            <Plus size={14} />
                        </button>
                    </div>

                    <div className="h-6 w-px bg-gray-300 dark:bg-white/10 mx-2"></div>

                    <button
                        onClick={() => setIsSessionLocked(!isSessionLocked)}
                        className={`p-2 rounded-xl transition-all ${isSessionLocked ? 'bg-red-50 text-red-500' : 'hover:bg-gray-100 dark:hover:bg-white/10 text-gray-500'}`}
                        title={isSessionLocked ? "Unlock Session" : "Lock Session"}
                    >
                        {isSessionLocked ? <Lock size={18} /> : <Unlock size={18} />}
                    </button>
                    <button className="bg-teal-500 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-lg shadow-teal-500/20 hover:bg-teal-600 transition-all flex items-center gap-2">
                        <Share2 size={16} /> Share
                    </button>
                </div>
            </header>

            {/* Main Workspace */}
            <div className="flex-grow flex relative overflow-hidden">

                {/* Tools Sidebar */}
                <div className="w-16 border-r border-gray-200 dark:border-white/10 flex flex-col items-center py-4 gap-2 bg-white/30 dark:bg-black/10 backdrop-blur-md z-10">
                    {[
                        { id: 'cursor', icon: <MousePointer2 size={20} />, label: 'Select' },
                        { id: 'pen', icon: <PenTool size={20} />, label: 'Pen' },
                        { id: 'text', icon: <Type size={20} />, label: 'Text' },
                        { id: 'sticky', icon: <StickyNote size={20} />, label: 'Sticky Note' },
                        { id: 'eraser', icon: <Eraser size={20} />, label: 'Eraser' },
                    ].map(tool => (
                        <button
                            key={tool.id}
                            onClick={() => setActiveTool(tool.id)}
                            className={`p-3 rounded-xl transition-all group relative ${activeTool === tool.id ? 'bg-teal-500 text-white shadow-lg shadow-teal-500/30' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-white/10'}`}
                            title={tool.label}
                        >
                            {tool.icon}
                            <span className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                                {tool.label}
                            </span>
                        </button>
                    ))}

                    {/* Pen Color Picker (when pen is active) */}
                    {activeTool === 'pen' && (
                        <div className="flex flex-col gap-1 mt-2 p-2 bg-white dark:bg-slate-800 rounded-xl shadow-lg">
                            {['#14b8a6', '#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6', '#000000'].map(color => (
                                <button
                                    key={color}
                                    onClick={() => setPenColor(color)}
                                    className={`w-6 h-6 rounded-full border-2 ${penColor === color ? 'border-gray-800 dark:border-white scale-110' : 'border-transparent'}`}
                                    style={{ backgroundColor: color }}
                                />
                            ))}
                        </div>
                    )}

                    <div className="mt-auto flex flex-col gap-2">
                        <button onClick={handleUndo} className="p-3 text-gray-500 hover:text-gray-800 dark:hover:text-white" title="Undo"><Undo size={20} /></button>
                        <button onClick={handleRedo} className="p-3 text-gray-500 hover:text-gray-800 dark:hover:text-white" title="Redo"><Redo size={20} /></button>
                    </div>
                </div>

                {/* Canvas Area */}
                <div
                    className="flex-grow bg-white/50 dark:bg-[#0f1126] relative overflow-hidden"
                    style={{ cursor: activeTool === 'pen' ? 'crosshair' : activeTool === 'eraser' ? 'cell' : activeTool === 'text' || activeTool === 'sticky' ? 'text' : 'default' }}
                    onClick={(e) => {
                        if (activeTool === 'sticky') handleAddStickyNote(e);
                        if (activeTool === 'text') handleAddText(e);
                    }}
                >
                    {/* Grid Pattern */}
                    <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #888 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>

                    {/* Drawing Canvas */}
                    <canvas
                        ref={canvasRef}
                        width={1200}
                        height={800}
                        className="absolute inset-0"
                        onMouseDown={handleCanvasMouseDown}
                        onMouseMove={handleCanvasMouseMove}
                        onMouseUp={handleCanvasMouseUp}
                        onMouseLeave={handleCanvasMouseUp}
                    />

                    {/* Sticky Notes */}
                    {stickyNotes.map(note => (
                        <motion.div
                            key={note.id}
                            drag={activeTool === 'cursor'}
                            dragMomentum={false}
                            onDragEnd={(_, info) => {
                                setStickyNotes(prev => prev.map(n => n.id === note.id ? { ...n, x: n.x + info.offset.x, y: n.y + info.offset.y } : n));
                            }}
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="absolute p-4 rounded-lg shadow-lg cursor-move min-w-[150px] max-w-[250px]"
                            style={{ left: note.x, top: note.y, backgroundColor: note.color }}
                        >
                            {editingStickyId === note.id ? (
                                <textarea
                                    autoFocus
                                    value={note.text}
                                    onChange={(e) => setStickyNotes(prev => prev.map(n => n.id === note.id ? { ...n, text: e.target.value } : n))}
                                    onBlur={() => { setEditingStickyId(null); saveHistory(); }}
                                    className="w-full bg-transparent resize-none outline-none text-gray-800 text-sm"
                                    rows={4}
                                />
                            ) : (
                                <div
                                    onClick={() => activeTool === 'cursor' && setEditingStickyId(note.id)}
                                    className="text-gray-800 text-sm whitespace-pre-wrap"
                                >
                                    {note.text}
                                </div>
                            )}
                            <button
                                onClick={() => handleDeleteSticky(note.id)}
                                className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600"
                            >
                                <X size={12} />
                            </button>
                        </motion.div>
                    ))}

                    {/* Text Items */}
                    {textItems.map(item => (
                        <motion.div
                            key={item.id}
                            drag={activeTool === 'cursor'}
                            dragMomentum={false}
                            onDragEnd={(_, info) => {
                                setTextItems(prev => prev.map(t => t.id === item.id ? { ...t, x: t.x + info.offset.x, y: t.y + info.offset.y } : t));
                            }}
                            className="absolute group"
                            style={{ left: item.x, top: item.y }}
                        >
                            {editingTextId === item.id ? (
                                <input
                                    autoFocus
                                    value={item.text}
                                    onChange={(e) => setTextItems(prev => prev.map(t => t.id === item.id ? { ...t, text: e.target.value } : t))}
                                    onBlur={() => { setEditingTextId(null); saveHistory(); }}
                                    className="bg-transparent outline-none border-b-2 border-teal-500 text-gray-800 dark:text-white text-lg font-medium px-2 py-1"
                                />
                            ) : (
                                <div
                                    onClick={() => activeTool === 'cursor' && setEditingTextId(item.id)}
                                    className="text-gray-800 dark:text-white text-lg font-medium cursor-text px-2 py-1"
                                >
                                    {item.text}
                                </div>
                            )}
                            <button
                                onClick={() => handleDeleteText(item.id)}
                                className="absolute -top-2 -right-4 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <X size={10} />
                            </button>
                        </motion.div>
                    ))}

                    {/* Simulated Cursors */}
                    <AnimatePresence>
                        {cursors.map(cursor => (
                            <motion.div
                                key={cursor.id}
                                initial={{ opacity: 0 }}
                                animate={{ x: cursor.x, y: cursor.y, opacity: 1 }}
                                transition={{ type: "spring", stiffness: 100, damping: 20 }}
                                className="absolute pointer-events-none z-50 flex items-start gap-1"
                            >
                                <MousePointer2
                                    size={20}
                                    fill={participants.find(p => p.id === cursor.id)?.color}
                                    color={participants.find(p => p.id === cursor.id)?.color}
                                />
                                <span
                                    className="px-2 py-0.5 rounded-full text-[10px] font-bold text-white shadow-sm whitespace-nowrap"
                                    style={{ backgroundColor: participants.find(p => p.id === cursor.id)?.color }}
                                >
                                    {participants.find(p => p.id === cursor.id)?.name}
                                </span>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>

                {/* Chat & Activity Sidebar */}
                <AnimatePresence>
                    {isChatOpen && (
                        <motion.div
                            initial={{ width: 0, opacity: 0 }}
                            animate={{ width: 320, opacity: 1 }}
                            exit={{ width: 0, opacity: 0 }}
                            className="border-l border-gray-200 dark:border-white/10 bg-white/40 dark:bg-black/20 backdrop-blur-md flex flex-col z-20"
                        >
                            <div className="p-4 border-b border-gray-200 dark:border-white/10 flex justify-between items-center">
                                <h3 className="font-bold text-gray-800 dark:text-white">Team Chat</h3>
                                <div className="flex gap-2">
                                    <button className="p-2 hover:bg-gray-100 dark:hover:bg-white/10 rounded-lg text-gray-500"><Phone size={18} /></button>
                                    <button className="p-2 hover:bg-gray-100 dark:hover:bg-white/10 rounded-lg text-gray-500"><Video size={18} /></button>
                                </div>
                            </div>

                            {/* Messages */}
                            <div className="flex-grow overflow-y-auto p-4 space-y-4">
                                {messages.map(msg => {
                                    const isMe = msg.senderId === '1';
                                    const sender = participants.find(p => p.id === msg.senderId);
                                    return (
                                        <div key={msg.id} className={`flex gap-3 ${isMe ? 'flex-row-reverse' : ''}`}>
                                            {!isMe && <img src={sender?.avatar} className="w-8 h-8 rounded-full object-cover" alt="avatar" />}
                                            <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${isMe ? 'bg-teal-500 text-white rounded-tr-none' : 'glass border border-white/50 dark:border-white/10 rounded-tl-none text-gray-700 dark:text-gray-200'}`}>
                                                <p>{msg.text}</p>
                                                <span className={`text-[10px] block mt-1 ${isMe ? 'text-teal-100' : 'text-gray-400'}`}>{msg.timestamp}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            {/* Input */}
                            <div className="p-4 border-t border-gray-200 dark:border-white/10">
                                <form onSubmit={handleSendMessage} className="relative">
                                    <input
                                        type="text"
                                        value={messageInput}
                                        onChange={(e) => setMessageInput(e.target.value)}
                                        placeholder="Type a message..."
                                        className="w-full pl-4 pr-12 py-3 rounded-xl bg-white dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none text-sm dark:text-white"
                                    />
                                    <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors">
                                        <Send size={16} />
                                    </button>
                                </form>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Sidebar Toggle */}
                <button
                    onClick={() => setIsChatOpen(!isChatOpen)}
                    className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-white/10 p-1 rounded-full shadow-md z-30 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
                >
                    {isChatOpen ? <ChevronRight size={16} className="text-gray-500" /> : <ChevronLeft size={16} className="text-gray-500" />}
                </button>

            </div>
        </div>
    );
};

export default LiveAssistant;
