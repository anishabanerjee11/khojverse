import React, { useEffect, useRef } from 'react';

interface ParticleBackgroundProps {
    isDarkMode: boolean;
}

const ParticleBackground: React.FC<ParticleBackgroundProps> = ({ isDarkMode }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let particles: Particle[] = [];
        let animationFrameId: number;

        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };

        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();

        class Particle {
            x: number;
            y: number;
            size: number;
            speedX: number;
            speedY: number;
            color: string;
            alpha: number;

            constructor() {
                this.x = Math.random() * canvas!.width;
                this.y = Math.random() * canvas!.height;
                this.size = Math.random() * 80 + 20; // Much larger bubbles
                this.speedX = Math.random() * 0.5 - 0.25; // Slower movement
                this.speedY = Math.random() * 0.5 - 0.25;
                // Teal/Theme colors with low opacity
                const hue = Math.random() * 40 + 160; // Teal range (160-200)
                this.color = `hsla(${hue}, 70%, 50%,`;
                this.alpha = Math.random() * 0.05 + 0.01; // Very subtle
            }

            update() {
                this.x += this.speedX;
                this.y += this.speedY;

                if (this.x > canvas!.width + this.size) this.x = -this.size;
                if (this.x < -this.size) this.x = canvas!.width + this.size;
                if (this.y > canvas!.height + this.size) this.y = -this.size;
                if (this.y < -this.size) this.y = canvas!.height + this.size;
            }

            draw() {
                if (!ctx) return;
                ctx.fillStyle = this.color + this.alpha + ')';
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        const init = () => {
            particles = [];
            // Fewer particles, but larger
            for (let i = 0; i < 15; i++) {
                particles.push(new Particle());
            }
        };

        const animate = () => {
            if (!ctx) return;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (let i = 0; i < particles.length; i++) {
                particles[i].update();
                particles[i].draw();
            }
            animationFrameId = requestAnimationFrame(animate);
        };

        init();
        animate();

        return () => {
            window.removeEventListener('resize', resizeCanvas);
            cancelAnimationFrame(animationFrameId);
        };
    }, [isDarkMode]);

    return (
        <canvas
            ref={canvasRef}
            className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 blur-3xl opacity-60" // Added blur for soft bubble effect
        />
    );
};

export default ParticleBackground;
