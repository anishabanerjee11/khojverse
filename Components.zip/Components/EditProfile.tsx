import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
    User as UserIcon, BookOpen, Lock, Bell, Palette, Sparkles,
    MapPin, Calendar, Mail, Phone, Github, Linkedin, Globe,
    Camera, Save, X, ChevronRight, Shield, Activity
} from 'lucide-react';
import { User } from '../types';

interface EditProfileProps {
    user: User;
    onSave: (updatedUser: User) => void;
    onCancel: () => void;
}

const EditProfile: React.FC<EditProfileProps> = ({ user, onSave, onCancel }) => {
    const [activeTab, setActiveTab] = useState('personal');
    const [formData, setFormData] = useState<User>(user);
    const [isSaving, setIsSaving] = useState(false);

    // Helper to update nested state - simplified for this demo
    const handleChange = (field: keyof User, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleDeepChange = (parent: keyof User, field: string, value: any) => {
        setFormData(prev => ({
            ...prev,
            [parent]: {
                ...(prev[parent] as any),
                [field]: value
            }
        }));
    };

    const tabs = [
        { id: 'personal', label: 'Personal Info', icon: <UserIcon size={18} /> },
        { id: 'academic', label: 'Academic', icon: <BookOpen size={18} /> },
        { id: 'contact', label: 'Contact', icon: <Mail size={18} /> },
        { id: 'customization', label: 'Customization', icon: <Palette size={18} /> },
        { id: 'privacy', label: 'Privacy', icon: <Lock size={18} /> },
        { id: 'status', label: 'Status', icon: <Activity size={18} /> },
    ];

    const handleSave = () => {
        setIsSaving(true);
        // Simulate API call
        setTimeout(() => {
            onSave(formData);
            setIsSaving(false);
        }, 1000);
    };

    return (
        <div className="flex flex-col lg:flex-row gap-8 max-w-7xl mx-auto pb-20">
            {/* Sidebar Navigation */}
            <div className="w-full lg:w-64 flex-shrink-0">
                <div className="glass rounded-3xl p-4 sticky top-24 border border-white/60 dark:border-white/5">
                    <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4 px-4">Edit Profile</h2>
                    <nav className="space-y-1">
                        {tabs.map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${activeTab === tab.id
                                        ? 'bg-teal-500 text-white shadow-lg shadow-teal-500/30'
                                        : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5'
                                    }`}
                            >
                                <div className="flex items-center gap-3">
                                    {tab.icon}
                                    <span className="font-medium text-sm">{tab.label}</span>
                                </div>
                                {activeTab === tab.id && <ChevronRight size={14} />}
                            </button>
                        ))}
                    </nav>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-grow">
                <div className="glass rounded-[40px] p-8 border border-white/60 dark:border-white/5 relative">

                    {/* Form Header */}
                    <div className="flex justify-between items-center mb-8 pb-6 border-b border-gray-100 dark:border-white/5">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                                {tabs.find(t => t.id === activeTab)?.label}
                            </h1>
                            <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
                                Manage your profile settings and preferences
                            </p>
                        </div>
                        <div className="flex gap-3">
                            <button
                                onClick={onCancel}
                                className="px-6 py-2.5 rounded-xl border border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-300 font-semibold hover:bg-gray-50 dark:hover:bg-white/5 transition-all"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={handleSave}
                                disabled={isSaving}
                                className="px-6 py-2.5 rounded-xl bg-teal-500 text-white font-bold shadow-lg shadow-teal-500/30 hover:bg-teal-600 transition-all flex items-center gap-2"
                            >
                                {isSaving ? <span className="animate-spin">⏳</span> : <Save size={18} />}
                                Save Changes
                            </button>
                        </div>
                    </div>

                    {/* Form Sections */}
                    <div className="space-y-8">

                        {activeTab === 'personal' && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                                {/* Avatar & Cover */}
                                <div className="space-y-6">
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Profile Visuals</label>
                                    <div className="relative h-48 rounded-2xl overflow-hidden bg-gray-100 dark:bg-black/40 group cursor-pointer border-2 border-dashed border-gray-300 dark:border-white/20 hover:border-teal-500 transition-all">
                                        <img src={formData.coverImage} alt="Cover" className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-all" />
                                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                                            <div className="bg-black/50 text-white px-4 py-2 rounded-full flex items-center gap-2 backdrop-blur-md">
                                                <Camera size={16} /> Change Cover
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex items-end gap-6 -mt-16 px-6 relative z-10">
                                        <div className="relative w-32 h-32 group cursor-pointer">
                                            <div className="w-32 h-32 rounded-full border-4 border-white dark:border-slate-800 overflow-hidden bg-white">
                                                <img src={formData.avatar} alt="Avatar" className="w-full h-full object-cover" />
                                            </div>
                                            <div className="absolute inset-0 flex items-center justify-center rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-all">
                                                <Camera size={24} className="text-white" />
                                            </div>
                                        </div>
                                        <div className="pb-4">
                                            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Click to upload new image</p>
                                            <p className="text-xs text-gray-400">JPG, PNG or GIF. Max 2MB.</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Full Name</label>
                                        <input
                                            type="text"
                                            value={formData.name}
                                            onChange={(e) => handleChange('name', e.target.value)}
                                            className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Username</label>
                                        <input
                                            type="text"
                                            value={formData.username}
                                            onChange={(e) => handleChange('username', e.target.value)}
                                            className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                        />
                                    </div>
                                    <div className="col-span-full space-y-2">
                                        <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Bio</label>
                                        <textarea
                                            value={formData.bio}
                                            onChange={(e) => handleChange('bio', e.target.value)}
                                            rows={3}
                                            className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white resize-none"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Location</label>
                                        <div className="relative">
                                            <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                            <input
                                                type="text"
                                                value={formData.location}
                                                onChange={(e) => handleChange('location', e.target.value)}
                                                className="w-full pl-10 pr-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Date of Birth</label>
                                        <div className="relative">
                                            <Calendar size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                            <input
                                                type="date"
                                                value={formData.dob}
                                                onChange={(e) => handleChange('dob', e.target.value)}
                                                className="w-full pl-10 pr-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'academic' && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Institution / College</label>
                                    <input
                                        type="text"
                                        value={formData.institution}
                                        onChange={(e) => handleChange('institution', e.target.value)}
                                        className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Course</label>
                                        <select
                                            value={formData.course}
                                            onChange={(e) => handleChange('course', e.target.value)}
                                            className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                        >
                                            <option>B.Tech Computer Science</option>
                                            <option>B.Sc Physics</option>
                                            <option>M.Tech AI</option>
                                        </select>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Semester</label>
                                        <select
                                            value={formData.semester}
                                            onChange={(e) => handleChange('semester', e.target.value)}
                                            className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                        >
                                            <option>1st Semester</option>
                                            <option>2nd Semester</option>
                                            <option>3rd Semester</option>
                                            <option>4th Semester</option>
                                            <option>5th Semester</option>
                                            <option>6th Semester</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Skills</label>
                                    <div className="flex flex-wrap gap-2 mb-2">
                                        {formData.skills?.map(skill => (
                                            <span key={skill} className="px-3 py-1 bg-teal-500/10 text-teal-600 rounded-full text-sm font-medium flex items-center gap-1">
                                                {skill} <button onClick={() => {
                                                    const newSkills = formData.skills?.filter(s => s !== skill);
                                                    handleChange('skills', newSkills);
                                                }}><X size={14} /></button>
                                            </span>
                                        ))}
                                    </div>
                                    <input
                                        type="text"
                                        placeholder="Type a skill and press Enter to add"
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter') {
                                                e.preventDefault();
                                                const val = e.currentTarget.value.trim();
                                                if (val && !formData.skills?.includes(val)) {
                                                    handleChange('skills', [...(formData.skills || []), val]);
                                                    e.currentTarget.value = '';
                                                }
                                            }
                                        }}
                                        className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                    />
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'contact' && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Email Address</label>
                                    <div className="relative">
                                        <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                        <input
                                            type="email"
                                            value={formData.email}
                                            onChange={(e) => handleChange('email', e.target.value)}
                                            className="w-full pl-10 pr-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Phone Number (Optional)</label>
                                    <div className="relative">
                                        <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                        <input
                                            type="text"
                                            value={formData.phoneNumber}
                                            onChange={(e) => handleChange('phoneNumber', e.target.value)}
                                            className="w-full pl-10 pr-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                        />
                                    </div>
                                </div>

                                <div className="h-px bg-gray-100 dark:bg-white/10 my-4"></div>

                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Social Profiles</label>
                                    <div className="space-y-4">
                                        <div className="relative">
                                            <Github size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                            <input
                                                type="text"
                                                placeholder="GitHub Profile URL"
                                                value={formData.socialLinks?.github || ''}
                                                onChange={(e) => handleDeepChange('socialLinks', 'github', e.target.value)}
                                                className="w-full pl-10 pr-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                            />
                                        </div>
                                        <div className="relative">
                                            <Linkedin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                            <input
                                                type="text"
                                                placeholder="LinkedIn Profile URL"
                                                value={formData.socialLinks?.linkedin || ''}
                                                onChange={(e) => handleDeepChange('socialLinks', 'linkedin', e.target.value)}
                                                className="w-full pl-10 pr-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                            />
                                        </div>
                                        <div className="relative">
                                            <Globe size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                            <input
                                                type="text"
                                                placeholder="Portfolio Website"
                                                value={formData.socialLinks?.website || ''}
                                                onChange={(e) => handleDeepChange('socialLinks', 'website', e.target.value)}
                                                className="w-full pl-10 pr-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'privacy' && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                                <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-black/20 hover:bg-gray-100 transition-colors">
                                    <div>
                                        <h4 className="font-bold text-gray-900 dark:text-white">Private Profile</h4>
                                        <p className="text-sm text-gray-500">Only your followers can see your posts and details.</p>
                                    </div>
                                    <div
                                        onClick={() => handleDeepChange('privacySettings', 'isPrivate', !formData.privacySettings?.isPrivate)}
                                        className={`w-12 h-6 rounded-full relative cursor-pointer transition-colors ${formData.privacySettings?.isPrivate ? 'bg-teal-500' : 'bg-gray-300 dark:bg-gray-700'}`}
                                    >
                                        <div className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${formData.privacySettings?.isPrivate ? 'translate-x-6' : ''}`}></div>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-black/20 hover:bg-gray-100 transition-colors">
                                    <div>
                                        <h4 className="font-bold text-gray-900 dark:text-white">Show Contact Info</h4>
                                        <p className="text-sm text-gray-500">Allow others to see your email and phone number.</p>
                                    </div>
                                    <div
                                        onClick={() => handleDeepChange('privacySettings', 'showContactInfo', !formData.privacySettings?.showContactInfo)}
                                        className={`w-12 h-6 rounded-full relative cursor-pointer transition-colors ${formData.privacySettings?.showContactInfo ? 'bg-teal-500' : 'bg-gray-300 dark:bg-gray-700'}`}
                                    >
                                        <div className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${formData.privacySettings?.showContactInfo ? 'translate-x-6' : ''}`}></div>
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {activeTab === 'status' && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                                    {['online', 'busy', 'studying', 'offline'].map(status => (
                                        <button
                                            key={status}
                                            onClick={() => handleChange('status', status)}
                                            className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 capitalize transition-all ${formData.status === status
                                                    ? 'border-teal-500 bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300'
                                                    : 'border-transparent bg-gray-50 dark:bg-black/20 text-gray-500 hover:bg-gray-100'
                                                }`}
                                        >
                                            <div className={`w-3 h-3 rounded-full ${status === 'online' ? 'bg-green-500' :
                                                    status === 'busy' ? 'bg-red-500' :
                                                        status === 'studying' ? 'bg-amber-500' : 'bg-gray-400'
                                                }`}></div>
                                            {status}
                                        </button>
                                    ))}
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Custom Status Message</label>
                                    <input
                                        type="text"
                                        placeholder="What are you up to?"
                                        value={formData.customStatusMessage || ''}
                                        onChange={(e) => handleChange('customStatusMessage', e.target.value)}
                                        className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none transition-all dark:text-white"
                                    />
                                </div>
                            </motion.div>
                        )}

                    </div>
                </div>
            </div>
        </div>
    );
};

export default EditProfile;
