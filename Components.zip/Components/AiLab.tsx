import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Sparkles, Image, Video, Palette, Wand2, Loader2, Download, X, Mic,
    BookOpen, Calculator, Code, FileText, BrainCircuit, Calendar,
    Briefcase, GraduationCap, Box, Glasses, Bot, ScanFace, PenTool,
    Languages, ShieldAlert, Users, Share2, Trophy, Search, LayoutGrid,
    Settings, Zap
} from 'lucide-react';

// Types
type ToolCategory = 'create' | 'learn' | 'productivity' | 'advanced' | 'community';

interface AITool {
    id: string;
    title: string;
    description: string;
    category: ToolCategory;
    icon: React.ReactNode;
    color: string;
    action: string;
    status: 'active' | 'coming_soon';
    isPro?: boolean;
}

const AILab: React.FC = () => {
    const [activeTab, setActiveTab] = useState<ToolCategory>('create');
    const [activeTool, setActiveTool] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [prompt, setPrompt] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [result, setResult] = useState<string | null>(null);

    // Tools Data
    const tools: AITool[] = [
        // CREATE
        { id: 'text-gen', title: 'Text Generator', description: 'Generate essays, code, notes, and creative writing.', category: 'create', icon: <FileText />, color: 'bg-blue-500', action: 'Generate', status: 'active' },
        { id: 'image-gen', title: 'Image Generator', description: 'Turn text descriptions into stunning visuals.', category: 'create', icon: <Image />, color: 'bg-pink-500', action: 'Create', status: 'active' },
        { id: 'video-syn', title: 'Video Synthesis', description: 'Create AI videos from text scripts.', category: 'create', icon: <Video />, color: 'bg-purple-500', action: 'Synthesize', status: 'active', isPro: true },
        { id: 'audio-ai', title: 'Audio & Voice AI', description: 'Text-to-speech, voice cloning, and noise removal.', category: 'create', icon: <Mic />, color: 'bg-orange-500', action: 'Record', status: 'active' },

        // LEARN
        { id: 'doubt-solver', title: 'AI Doubt Solver', description: 'Get instant explanations for complex topics.', category: 'learn', icon: <BrainCircuit />, color: 'bg-emerald-500', action: 'Solve', status: 'active' },
        { id: 'flashcards', title: 'Notes to Flashcards', description: 'Convert study notes into revision cards.', category: 'learn', icon: <BookOpen />, color: 'bg-yellow-500', action: 'Convert', status: 'active' },
        { id: 'quiz-gen', title: 'Quiz Generator', description: 'Create MCQs from any topic or text.', category: 'learn', icon: <Zap />, color: 'bg-red-500', action: 'Generate', status: 'active' },
        { id: 'code-debug', title: 'Code Debugger', description: 'Fix bugs and optimize your code.', category: 'learn', icon: <Code />, color: 'bg-blue-600', action: 'Debug', status: 'active' },
        { id: 'math-solver', title: 'Math Solver', description: 'Step-by-step solutions for math problems.', category: 'learn', icon: <Calculator />, color: 'bg-indigo-500', action: 'Solve', status: 'active' },

        // PRODUCTIVITY
        { id: 'study-plan', title: 'Study Planner', description: 'AI-generated personalized study schedules.', category: 'productivity', icon: <Calendar />, color: 'bg-teal-500', action: 'Plan', status: 'active' },
        { id: 'resume-build', title: 'Resume Builder', description: 'Create ATS-friendly resumes and SOPs.', category: 'productivity', icon: <FileText />, color: 'bg-slate-500', action: 'Build', status: 'active' },
        { id: 'career-ai', title: 'Career Suggestion', description: 'Discover career paths based on your skills.', category: 'productivity', icon: <Briefcase />, color: 'bg-amber-500', action: 'Analyze', status: 'active' },

        // ADVANCED
        { id: '3d-gen', title: '3D Model Gen', description: 'Generate 3D assets from text prompts.', category: 'advanced', icon: <Box />, color: 'bg-rose-500', action: 'Model', status: 'coming_soon', isPro: true },
        { id: 'ar-vr', title: 'AR/VR Viewer', description: 'Visualize objects in augmented reality.', category: 'advanced', icon: <Glasses />, color: 'bg-violet-500', action: 'View', status: 'coming_soon' },
        { id: 'chatbot-build', title: 'Chatbot Builder', description: 'Train custom AI agents for specific tasks.', category: 'advanced', icon: <Bot />, color: 'bg-cyan-500', action: 'Train', status: 'active', isPro: true },
        { id: 'translator', title: 'Translator', description: 'Real-time language translation and grammar fixes.', category: 'advanced', icon: <Languages />, color: 'bg-lime-500', action: 'Translate', status: 'active' },
        { id: 'plagiarism', title: 'Plagiarism Checker', description: 'Check content uniqueness and AI detection.', category: 'advanced', icon: <ShieldAlert />, color: 'bg-red-600', action: 'Check', status: 'active' },

        // COMMUNITY
        { id: 'gallery', title: 'Public Gallery', description: 'Explore creations by other students.', category: 'community', icon: <LayoutGrid />, color: 'bg-fuchsia-500', action: 'Explore', status: 'active' },
        { id: 'collab', title: 'Collaboration Rooms', description: 'Work on AI projects with teammates.', category: 'community', icon: <Users />, color: 'bg-indigo-600', action: 'Join', status: 'active' },
        { id: 'remix', title: 'Remix Station', description: 'Modify and improve existing projects.', category: 'community', icon: <Share2 />, color: 'bg-pink-600', action: 'Remix', status: 'active' },
    ];

    const filteredTools = tools.filter(t =>
        (t.category === activeTab) &&
        (t.title.toLowerCase().includes(searchQuery.toLowerCase()) || t.description.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    const tabs: { id: ToolCategory, label: string, icon: React.ReactNode }[] = [
        { id: 'create', label: 'Create', icon: <Wand2 size={18} /> },
        { id: 'learn', label: 'Learn', icon: <GraduationCap size={18} /> },
        { id: 'productivity', label: 'Productivity', icon: <Zap size={18} /> },
        { id: 'advanced', label: 'Advanced', icon: <BrainCircuit size={18} /> },
        { id: 'community', label: 'Community', icon: <Users size={18} /> },
    ];

    const handleGenerate = () => {
        if (!prompt) return;
        setIsGenerating(true);
        // Simulate generation
        setTimeout(() => {
            setIsGenerating(false);
            setResult('AI Generated Content Placeholder');
        }, 2000);
    };

    return (
        <div className="space-y-8 min-h-screen pb-20">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                    <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white flex items-center gap-3">
                        AI Studio <Sparkles className="text-teal-500" />
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 font-medium mt-2">
                        Your futuristic lab to experiment, build, and innovate.
                    </p>
                </div>

                <div className="flex items-center gap-4">
                    {/* Search */}
                    <div className="glass rounded-2xl px-4 py-2 flex items-center gap-3 border border-gray-200 dark:border-white/10 focus-within:ring-2 ring-teal-500 transition-all w-full md:w-64">
                        <Search className="text-gray-400" size={18} />
                        <input
                            type="text"
                            placeholder="Find a tool..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="bg-transparent border-none outline-none w-full text-sm text-gray-700 dark:text-white placeholder:text-gray-400"
                        />
                    </div>

                    <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-2xl bg-teal-50 dark:bg-teal-900/20 border border-teal-100 dark:border-teal-900/30 text-teal-600 dark:text-teal-400 font-bold text-sm">
                        <Zap size={16} fill="currentColor" />
                        <span>Free Credits</span>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="sticky top-20 z-40 bg-[#f7f9fb]/80 dark:bg-[#0a0b1e]/80 backdrop-blur-xl py-2 -mx-4 px-4 overflow-x-auto">
                <div className="flex gap-2 min-w-max">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => { setActiveTab(tab.id); setActiveTool(null); }}
                            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-semibold transition-all duration-300 ${activeTab === tab.id
                                    ? 'bg-teal-500 text-white shadow-lg shadow-teal-500/25 scale-105'
                                    : 'glass text-gray-600 dark:text-gray-400 hover:bg-white dark:hover:bg-white/5'
                                }`}
                        >
                            {tab.icon}
                            {tab.label}
                        </button>
                    ))}
                </div>
            </div>

            <AnimatePresence mode="wait">
                {!activeTool ? (
                    /* Tool Grid */
                    <motion.div
                        key="grid"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                    >
                        {filteredTools.map((tool, index) => (
                            <motion.div
                                key={tool.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.05 }}
                                onClick={() => tool.status === 'active' && setActiveTool(tool.id)}
                                className={`glass p-6 rounded-[32px] border border-white/60 dark:border-white/5 relative group overflow-hidden cursor-pointer transition-all hover:-translate-y-1 hover:shadow-xl ${tool.status !== 'active' ? 'opacity-70 grayscale' : ''}`}
                            >
                                <div className={`absolute -right-12 -top-12 w-32 h-32 rounded-full ${tool.color} opacity-10 group-hover:scale-150 transition-transform duration-500`}></div>

                                <div className="flex justify-between items-start mb-6 relative">
                                    <div className={`w-14 h-14 rounded-2xl ${tool.color} bg-opacity-10 flex items-center justify-center text-gray-800 dark:text-white group-hover:scale-110 transition-transform duration-300 shadow-sm`}>
                                        {tool.icon}
                                    </div>
                                    {tool.isPro && (
                                        <span className="bg-gradient-to-r from-amber-400 to-orange-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-lg">PRO</span>
                                    )}
                                    {tool.status === 'coming_soon' && (
                                        <span className="bg-gray-200 dark:bg-white/10 text-gray-500 dark:text-gray-400 text-[10px] font-bold px-2 py-0.5 rounded-full">SOON</span>
                                    )}
                                </div>

                                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 relative">{tool.title}</h3>
                                <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed mb-6 relative h-10 line-clamp-2">{tool.description}</p>

                                <div className="flex items-center justify-between relative mt-auto">
                                    <span className={`text-xs font-bold uppercase tracking-wider ${tool.status === 'active' ? 'text-teal-500' : 'text-gray-400'}`}>
                                        {tool.status === 'active' ? 'Ready' : 'In Dev'}
                                    </span>
                                    <button className={`p-2 rounded-full ${tool.status === 'active' ? 'bg-gray-100 dark:bg-white/10 text-gray-900 dark:text-white group-hover:bg-teal-500 group-hover:text-white' : 'bg-gray-100 dark:bg-white/5 text-gray-300'} transition-colors`}>
                                        <Wand2 size={18} />
                                    </button>
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>
                ) : (
                    /* Active Tool Workspace */
                    <motion.div
                        key="workspace"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="glass rounded-[40px] border border-white/60 dark:border-white/5 overflow-hidden flex flex-col h-[calc(100vh-180px)]"
                    >
                        {/* Workspace Header */}
                        <div className="px-8 py-5 border-b border-gray-100 dark:border-white/5 flex justify-between items-center bg-white/40 dark:bg-black/20 backdrop-blur-md">
                            <div className="flex items-center gap-4">
                                <button
                                    onClick={() => setActiveTool(null)}
                                    className="p-2 hover:bg-gray-100 dark:hover:bg-white/10 rounded-xl transition-colors text-gray-500"
                                >
                                    <X size={20} />
                                </button>
                                <div className={`p-2 rounded-lg ${tools.find(t => t.id === activeTool)?.color} bg-opacity-20`}>
                                    <span className="text-gray-800 dark:text-white">
                                        {tools.find(t => t.id === activeTool)?.icon}
                                    </span>
                                </div>
                                <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                                    {tools.find(t => t.id === activeTool)?.title}
                                </h2>
                            </div>

                            <div className="flex items-center gap-3">
                                <button className="p-2 hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg text-gray-500" title="Settings">
                                    <Settings size={20} />
                                </button>
                                <button className="px-5 py-2 bg-teal-500 text-white rounded-xl font-bold shadow-lg shadow-teal-500/20 hover:bg-teal-600 transition-all flex items-center gap-2" disabled={isGenerating} onClick={handleGenerate}>
                                    {isGenerating ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                                    {tools.find(t => t.id === activeTool)?.action}
                                </button>
                            </div>
                        </div>

                        {/* Workspace Body */}
                        <div className="flex flex-col lg:flex-row h-full overflow-hidden">
                            {/* Input Panel */}
                            <div className="w-full lg:w-1/3 border-r border-gray-100 dark:border-white/5 p-6 space-y-6 overflow-y-auto">
                                <div>
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 block">Prompt / Input</label>
                                    <textarea
                                        value={prompt}
                                        onChange={(e) => setPrompt(e.target.value)}
                                        placeholder={`Enter instructions for ${tools.find(t => t.id === activeTool)?.title}...`}
                                        className="w-full h-40 p-4 rounded-2xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:ring-2 focus:ring-teal-500 outline-none resize-none text-gray-800 dark:text-white transition-all"
                                    />
                                </div>

                                {/* Tool Specific Controls (Mock) */}
                                <div className="space-y-4">
                                    <div className="p-4 rounded-2xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/5">
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Creativity Level</span>
                                            <span className="text-xs font-bold text-teal-500">High</span>
                                        </div>
                                        <input type="range" className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-teal-500" />
                                    </div>

                                    <div className="grid grid-cols-2 gap-3">
                                        <button className="p-3 rounded-xl border border-gray-200 dark:border-white/10 hover:border-teal-500 hover:bg-teal-50 dark:hover:bg-teal-900/10 transition-all text-sm font-medium text-gray-600 dark:text-gray-300">
                                            Standard Mode
                                        </button>
                                        <button className="p-3 rounded-xl border border-gray-200 dark:border-white/10 hover:border-teal-500 hover:bg-teal-50 dark:hover:bg-teal-900/10 transition-all text-sm font-medium text-gray-600 dark:text-gray-300">
                                            Professional
                                        </button>
                                    </div>
                                </div>
                            </div>

                            {/* Output Panel */}
                            <div className="w-full lg:w-2/3 bg-gray-50/50 dark:bg-black/20 p-8 flex items-center justify-center relative">
                                {isGenerating ? (
                                    <div className="text-center">
                                        <Loader2 size={48} className="animate-spin text-teal-500 mx-auto mb-4" />
                                        <p className="text-gray-500 dark:text-gray-400 animate-pulse">AI is working its magic...</p>
                                    </div>
                                ) : result ? (
                                    <div className="w-full h-full bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-gray-200 dark:border-white/5 flex items-center justify-center relative group p-8">
                                        <p className="text-gray-800 dark:text-gray-200 font-serif text-lg leading-relaxed">
                                            {result === 'AI Generated Content Placeholder' ?
                                                "This is a placeholder for the AI generated content. In a real application, the actual text, image, or video result would appear here based on the tool selected."
                                                : result}
                                        </p>
                                        <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button className="p-2 bg-white dark:bg-slate-800 shadow-md rounded-lg text-gray-600 hover:text-teal-500 transition-colors">
                                                <Download size={18} />
                                            </button>
                                            <button className="p-2 bg-white dark:bg-slate-800 shadow-md rounded-lg text-gray-600 hover:text-teal-500 transition-colors">
                                                <Share2 size={18} />
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-center opacity-40">
                                        <div className={`w-24 h-24 mx-auto mb-6 rounded-3xl ${tools.find(t => t.id === activeTool)?.color} bg-opacity-10 flex items-center justify-center text-gray-800 dark:text-white`}>
                                            {tools.find(t => t.id === activeTool)?.icon}
                                        </div>
                                        <h3 className="text-2xl font-bold text-gray-400 dark:text-gray-600">Workspace Ready</h3>
                                        <p className="text-gray-400 dark:text-gray-600 mt-2">Enter a prompt to start creating.</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default AILab;
