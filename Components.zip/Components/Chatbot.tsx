import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Sparkles, Loader2, Maximize2, Minimize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { generateText } from '../lib/gemini';

const Chatbot: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isExpanded, setIsExpanded] = useState(false);
    const [messages, setMessages] = useState<{ text: string, sender: 'user' | 'bot', timestamp: Date }[]>([
        { text: "Hello! I'm Multiverse Muse. I can help you explore ideas, research topics, or just brainstorm. Ask me anything!", sender: 'bot', timestamp: new Date() }
    ]);
    const [inputText, setInputText] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        if (isOpen) scrollToBottom();
    }, [messages, isOpen]);

    const handleSend = async () => {
        if (!inputText.trim()) return;

        const userMessage = { text: inputText, sender: 'user' as const, timestamp: new Date() };
        setMessages(prev => [...prev, userMessage]);
        setInputText('');
        setIsTyping(true);

        // Call Gemini API
        try {
            const response = await generateText(inputText);
            const botMessage = { text: response, sender: 'bot' as const, timestamp: new Date() };
            setMessages(prev => [...prev, botMessage]);
        } catch (error) {
            const errorMessage = { text: "I'm having trouble connecting to the multiverse right now. Please try again.", sender: 'bot' as const, timestamp: new Date() };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsTyping(false);
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') handleSend();
    };

    return (
        <div className="relative z-[100] ml-4">
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.8, y: -10, x: -10 }}
                        animate={{
                            opacity: 1,
                            scale: 1,
                            y: 0,
                            x: 0,
                            width: isExpanded ? '800px' : '320px',
                            height: isExpanded ? '80vh' : '450px'
                        }}
                        exit={{ opacity: 0, scale: 0.8, y: -10, x: -10 }}
                        transition={{ type: "spring", damping: 25, stiffness: 300 }}
                        className={`absolute top-16 left-0 glass rounded-3xl rounded-tl-none shadow-2xl border border-white/60 dark:border-white/10 flex flex-col overflow-hidden origin-top-left z-[101] ${isExpanded ? 'fixed top-20 left-8 max-w-[calc(100vw-4rem)] max-h-[calc(100vh-8rem)]' : 'w-80 h-[450px]'}`}
                    >
                        {/* Header */}
                        <div className="p-4 bg-gradient-to-r from-teal-500 to-emerald-600 text-white flex justify-between items-center shrink-0">
                            <div className="flex items-center gap-2">
                                <Sparkles size={18} className="animate-pulse" />
                                <h3 className="font-bold">Multiverse Muse</h3>
                            </div>
                            <div className="flex items-center gap-1">
                                <button
                                    onClick={() => setIsExpanded(!isExpanded)}
                                    className="hover:bg-white/20 rounded-full p-1.5 transition-colors"
                                >
                                    {isExpanded ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                                </button>
                                <button
                                    onClick={() => setIsOpen(false)}
                                    className="hover:bg-white/20 rounded-full p-1.5 transition-colors"
                                >
                                    <X size={18} />
                                </button>
                            </div>
                        </div>

                        {/* Messages Area */}
                        <div className="flex-grow p-4 overflow-y-auto bg-white/50 dark:bg-black/20 space-y-4 custom-scrollbar">
                            {messages.map((msg, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div
                                        className={`max-w-[80%] p-3.5 rounded-2xl text-sm leading-relaxed ${msg.sender === 'user'
                                            ? 'bg-teal-500 text-white rounded-tr-none shadow-lg shadow-teal-500/20'
                                            : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100 rounded-tl-none border border-gray-100 dark:border-white/5 shadow-sm'
                                            }`}
                                    >
                                        {msg.text}
                                        <p className={`text-[10px] mt-1 opacity-70 ${msg.sender === 'user' ? 'text-teal-100' : 'text-gray-400'}`}>
                                            {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </p>
                                    </div>
                                </motion.div>
                            ))}
                            {isTyping && (
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    className="flex justify-start"
                                >
                                    <div className="bg-white dark:bg-gray-800 p-3 rounded-2xl rounded-tl-none border border-gray-100 dark:border-white/5 flex gap-1 items-center">
                                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                                    </div>
                                </motion.div>
                            )}
                            <div ref={messagesEndRef} />
                        </div>

                        {/* Input Area */}
                        <div className="p-4 border-t border-gray-100 dark:border-white/10 bg-white/80 dark:bg-black/40 shrink-0">
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    value={inputText}
                                    onChange={(e) => setInputText(e.target.value)}
                                    onKeyPress={handleKeyPress}
                                    placeholder="Ask anything..."
                                    className="w-full bg-transparent outline-none text-sm text-gray-700 dark:text-gray-200 placeholder:text-gray-400"
                                />
                                <button
                                    onClick={handleSend}
                                    disabled={!inputText.trim() || isTyping}
                                    className={`p-2 rounded-xl transition-all ${inputText.trim() && !isTyping ? 'text-teal-500 hover:bg-teal-50 dark:hover:bg-teal-900/20' : 'text-gray-300 dark:text-gray-600 cursor-not-allowed'}`}
                                >
                                    <Send size={20} />
                                </button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <motion.button
                layoutId="chat-fab"
                onClick={() => setIsOpen(!isOpen)}
                whileHover={{ scale: 1.05, rotate: [0, -5, 5, 0] }}
                whileTap={{ scale: 0.9 }}
                className="w-12 h-10 bg-gradient-to-br from-teal-400 to-white text-teal-800 rounded-[10%_40%_40%_40%] shadow-lg shadow-teal-500/20 flex items-center justify-center relative overflow-hidden group hover:rotate-0 transition-all duration-300"
            >
                <div className="absolute inset-0 bg-white/40 blur-sm rounded-full transform -translate-x-0.5 -translate-y-0.5"></div>
                {!isOpen ? (
                    <div className="relative z-10">
                        <MessageCircle size={20} strokeWidth={2.5} />
                        <motion.div
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ repeat: Infinity, duration: 2, repeatType: "reverse" }}
                            className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-400 rounded-full border border-white"
                        />
                    </div>
                ) : (
                    <X size={20} className="relative z-10" />
                )}
            </motion.button>
        </div>
    );
};

export default Chatbot;
